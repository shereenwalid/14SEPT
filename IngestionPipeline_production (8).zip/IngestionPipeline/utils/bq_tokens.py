"""
utils/bq_tokens.py — daily token consumption reporting.

Writes one row per DAY per application to

    complex_fixed_daily_tokens_consumption
    (date, app_acronym, name, input_tokens, output_tokens, total_tokens)

Every run ADDS its usage to that day's row rather than inserting a new one,
so the table holds a single daily total however many times the pipeline runs.

The upsert is a single MERGE statement, which BigQuery applies atomically.
That matters because the scheduled run and a manual backfill can finish close
together; a read-then-write would lose one of them. MERGE also avoids the
streaming-buffer problem — rows written by streaming inserts cannot be
updated for up to 90 minutes, whereas DML-written rows can be updated
immediately.

Reporting never fails a pipeline run: any error here is logged and swallowed.
"""

import logging
from datetime import date as _date
from typing import Optional

logger = logging.getLogger(__name__)

_SCHEMA_CACHE: dict = {}


def _date_column_is_string(client, table_ref: str) -> bool:
    """Is the `date` column STRING or a real DATE?

    The table may have been created either way. Reading the schema once and
    caching it avoids forcing a config setting that would silently break the
    MERGE if it did not match reality.
    """
    if table_ref in _SCHEMA_CACHE:
        return _SCHEMA_CACHE[table_ref]
    is_string = False
    try:
        table = client.get_table(table_ref)
        for field in table.schema:
            if field.name.lower() == "date":
                is_string = field.field_type.upper() == "STRING"
                break
    except Exception:
        logger.debug("Could not read schema for %s; assuming DATE", table_ref)
    _SCHEMA_CACHE[table_ref] = is_string
    return is_string


def write_daily_tokens(
    project_id: str,
    dataset: str,
    table: str,
    app_acronym: str,
    app_name: str,
    input_tokens: int,
    output_tokens: int,
    total_tokens: int,
    run_date: Optional[_date] = None,
    date_format: str = "%d-%m-%Y",
) -> bool:
    """Add this run's token usage to today's row. Returns True on success."""
    if not (input_tokens or output_tokens or total_tokens):
        logger.info("[Tokens] No usage recorded this run — nothing to report")
        return True

    try:
        from google.cloud import bigquery
    except ImportError:
        logger.warning(
            "[Tokens] google-cloud-bigquery not installed — daily token "
            "reporting skipped"
        )
        return False

    run_date = run_date or _date.today()

    # The dataset may already carry its own project (the BSP dataset is
    # "vf-ie-datahub.vfie_dh_lake_customer_complex_fixed_s"). Prepending the
    # project again would build an invalid four-part name.
    ds = (dataset or "").strip().strip("`")
    fqn = f"{ds}.{table}" if "." in ds else f"{project_id}.{ds}.{table}"
    table_ref = f"`{fqn}`"

    try:
        client = bigquery.Client(project=project_id)

        if _date_column_is_string(client, fqn):
            date_param = bigquery.ScalarQueryParameter(
                "run_date", "STRING", run_date.strftime(date_format)
            )
            date_type = "STRING"
        else:
            date_param = bigquery.ScalarQueryParameter(
                "run_date", "DATE", run_date
            )
            date_type = "DATE"

        # One atomic statement: increment when the day already has a row,
        # insert when it does not.
        sql = f"""
        MERGE {table_ref} AS T
        USING (
          SELECT
            @run_date        AS `date`,
            @app_acronym     AS `app_acronym`,
            @app_name        AS `name`,
            @input_tokens    AS `input_tokens`,
            @output_tokens   AS `output_tokens`,
            @total_tokens    AS `total_tokens`
        ) AS S
        ON T.`date` = S.`date` AND T.`app_acronym` = S.`app_acronym`
        WHEN MATCHED THEN UPDATE SET
          `input_tokens`  = IFNULL(T.`input_tokens`, 0)  + S.`input_tokens`,
          `output_tokens` = IFNULL(T.`output_tokens`, 0) + S.`output_tokens`,
          `total_tokens`  = IFNULL(T.`total_tokens`, 0)  + S.`total_tokens`
        WHEN NOT MATCHED THEN INSERT
          (`date`, `app_acronym`, `name`,
           `input_tokens`, `output_tokens`, `total_tokens`)
        VALUES
          (S.`date`, S.`app_acronym`, S.`name`,
           S.`input_tokens`, S.`output_tokens`, S.`total_tokens`)
        """

        job = client.query(
            sql,
            job_config=bigquery.QueryJobConfig(
                query_parameters=[
                    date_param,
                    bigquery.ScalarQueryParameter(
                        "app_acronym", "STRING", app_acronym),
                    bigquery.ScalarQueryParameter(
                        "app_name", "STRING", app_name),
                    bigquery.ScalarQueryParameter(
                        "input_tokens", "INT64", int(input_tokens)),
                    bigquery.ScalarQueryParameter(
                        "output_tokens", "INT64", int(output_tokens)),
                    bigquery.ScalarQueryParameter(
                        "total_tokens", "INT64", int(total_tokens)),
                ]
            ),
        )
        job.result()

        logger.info(
            "[Tokens] %s %s (%s date column): +%d in / +%d out / +%d total "
            "added to %s",
            run_date.strftime(date_format), app_acronym, date_type,
            input_tokens, output_tokens, total_tokens, fqn,
        )
        return True

    except Exception:
        logger.exception(
            "[Tokens] Could not write daily token usage to %s — the run is "
            "unaffected", fqn,
        )
        return False
