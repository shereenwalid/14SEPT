"""
probe_proxy.py — find out what the LLM proxy actually accepts.

Run this on the VM, in the project folder, with the same credentials the
pipeline uses:

    python probe_proxy.py

It sends four small requests and reports which succeed:

  1. TEXT              — the baseline; should always work.
  2. IMAGE part        — expected to fail (that is why we are here).
  3. PDF part, text    — a PDF whose content is real text.
  4. PDF part, IMAGE   — a PDF whose only content is a screenshot. This is
                         the one that matters: it tells us whether wrapping
                         a PO screenshot in a PDF recovers native vision.

Nothing is written to GCS and no pipeline state is touched.
"""

import io
import json
import sys

sys.path.insert(0, ".")

from utils.config_loader import load_config
from utils.gemini_client import GeminiClient


def make_png() -> bytes:
    """A small image containing text no model could guess."""
    from PIL import Image, ImageDraw, ImageFont

    text = [
        "Standard Purchase Order 8817342",
        "Supplier: Vodafone Ireland Limited",
        "Contract Term: 36 Months",
    ]
    img = Image.new("RGB", (900, 200), "white")
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype(
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 26
        )
    except Exception:
        font = ImageFont.load_default()
    for i, line in enumerate(text):
        draw.text((25, 25 + i * 50), line, fill="black", font=font)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def png_to_pdf(png: bytes) -> bytes:
    from PIL import Image

    img = Image.open(io.BytesIO(png))
    if img.mode in ("RGBA", "P", "LA"):
        img = img.convert("RGB")
    buf = io.BytesIO()
    img.save(buf, format="PDF", resolution=150.0)
    return buf.getvalue()


def text_pdf() -> bytes:
    """A PDF with a real text layer, for comparison."""
    from PIL import Image, ImageDraw, ImageFont

    # Pillow-only text PDF: rendered text, then saved as PDF. (A true
    # text-layer PDF would need reportlab; visually this is equivalent for
    # the purposes of the probe.)
    return png_to_pdf(make_png())


PROMPT = (
    "Read this document and return ONLY compact JSON with the keys "
    "po_number, supplier, contract_term. No prose, no code fences."
)


def show(label: str, fn):
    print(f"\n--- {label} ---")
    try:
        out = fn()
        snippet = (out or "").strip().replace("\n", " ")[:200]
        ok = "8817342" in (out or "")
        print(f"  RESULT : {'PASS' if ok else 'RESPONDED'}")
        print(f"  OUTPUT : {snippet}")
        if not ok:
            print("  (no PO number found — the model responded but could "
                  "not read the content)")
        return ok
    except Exception as exc:
        msg = str(exc).replace("\n", " ")[:300]
        print(f"  RESULT : FAILED")
        print(f"  ERROR  : {msg}")
        return False


def main() -> int:
    cfg = load_config()
    client = GeminiClient(
        project_id=cfg.llm.project_id,
        location=cfg.gcp.location,
        proxy_url=cfg.llm.proxy_url,
        model_name=cfg.gemini.model,
        temperature=cfg.gemini.temperature,
        max_output_tokens=cfg.gemini.max_output_tokens,
    )
    print(f"Model : {cfg.gemini.model}")
    print(f"Proxy : {cfg.llm.proxy_url}")

    png = make_png()
    pdf_img = png_to_pdf(png)

    r_text = show(
        "1. TEXT part (baseline)",
        lambda: client.extract_from_text(
            "Standard Purchase Order 8817342, supplier Vodafone Ireland "
            "Limited, contract term 36 Months.",
            PROMPT,
        ),
    )
    r_img = show(
        "2. IMAGE part (image/png)",
        lambda: client.extract_from_image_bytes(
            image_bytes=png, mime_type="image/png", system_prompt=PROMPT
        ),
    )
    r_pdf = show(
        "3. PDF part containing ONLY an image (the important one)",
        lambda: client.extract_from_pdf_bytes(pdf_img, PROMPT),
    )

    print("\n================ SUMMARY ================")
    print(f"  text part          : {'OK' if r_text else 'BLOCKED/FAILED'}")
    print(f"  image part         : {'OK' if r_img else 'BLOCKED/FAILED'}")
    print(f"  image-in-PDF part  : {'OK' if r_pdf else 'BLOCKED/FAILED'}")
    print()
    if r_pdf:
        print("  => PDF wrapping WORKS. Screenshots and scanned POs will be")
        print("     read with native vision quality; OCR is not needed.")
    elif r_img:
        print("  => Images are fine after all; no fallback required.")
    else:
        print("  => Both image and PDF-wrapped image are blocked. OCR is the")
        print("     only route until MULTIMODAL_SUPPORT=true is set on the")
        print("     proxy. Check which OCR packages your mirror carries.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
