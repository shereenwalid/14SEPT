"""
utils/ocr.py — image → text, for when the LLM cannot accept image input.

The Vodafone LLM proxy rejects image parts ("Image is not allowed for the
requested LLM", HTTP 403). Rather than losing the content of scanned POs,
signed forms and pasted email screenshots, we OCR them locally and send the
resulting TEXT to Gemini, which then produces the same structured JSON.

Engines are tried in order and the first available one wins:

  1. pytesseract  — wraps the Tesseract binary. Accurate and fast, but needs
                    the `tesseract-ocr` SYSTEM package, which cannot be
                    pip-installed. Fine in a container; NOT available on a
                    stock Cloud Run Function buildpack.
  2. rapidocr-onnxruntime — pure pip, no system packages, bundles ONNX
                    models. Slower and heavier to install, but it is the
                    option that works where you cannot apt-get.

If neither is present the caller is told so explicitly, so the failure is
visible rather than silent.
"""

import io
import logging
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

_ENGINE = None          # resolved engine name, or "" if none available
_RAPID = None           # cached rapidocr instance (model load is expensive)


class OCRUnavailable(RuntimeError):
    """No OCR engine is installed in this environment."""


def _preprocess(image_bytes: bytes, max_dim: int = 2600):
    """Load, orient and upscale-limit an image for better OCR accuracy.

    Screenshots pasted into spreadsheets are often small; Tesseract does
    noticeably better on greyscale at a sane resolution than on a tiny
    colour thumbnail.
    """
    from PIL import Image, ImageOps

    img = Image.open(io.BytesIO(image_bytes))
    img = ImageOps.exif_transpose(img)
    if img.mode not in ("L", "RGB"):
        img = img.convert("RGB")
    w, h = img.size
    if max(w, h) > max_dim:                 # avoid pathological memory use
        scale = max_dim / float(max(w, h))
        img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
    elif max(w, h) < 1000:                  # upscale small screenshots
        scale = min(2.0, 1000.0 / float(max(w, h)))
        img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
    return ImageOps.grayscale(img)


def _try_rapidocr() -> bool:
    try:
        import rapidocr_onnxruntime  # noqa: F401
        return True
    except Exception:
        return False


def _try_tesseract() -> bool:
    try:
        import pytesseract
        pytesseract.get_tesseract_version()   # fails if the binary is absent
        return True
    except Exception:
        return False


def image_to_pdf(image_bytes: bytes) -> bytes:
    """Wrap an image in a single-page PDF.

    Proxies that reject image/* parts generally still allow
    application/pdf, and Gemini renders PDF pages visually — so this
    recovers NATIVE image understanding rather than falling back to OCR,
    and needs no packages beyond Pillow, which is already a dependency.
    """
    from PIL import Image

    img = Image.open(io.BytesIO(image_bytes))
    if img.mode in ("RGBA", "P", "LA"):
        img = img.convert("RGB")     # PDF has no alpha channel
    buf = io.BytesIO()
    img.save(buf, format="PDF", resolution=150.0)
    return buf.getvalue()


def available_engine() -> str:
    """Name of the OCR engine that will be used, or "" if none.

    RapidOCR is preferred: it installs entirely through pip (bundled ONNX
    models, no system packages), so it works unchanged on a Cloud Run
    buildpack where the Tesseract binary cannot be installed. Tesseract is
    used when present and RapidOCR is not — it is lighter and faster, just
    harder to deploy.

    Override with OCR_ENGINE=rapidocr|pytesseract.
    """
    global _ENGINE
    if _ENGINE is not None:
        return _ENGINE

    import os
    preferred = (os.environ.get("OCR_ENGINE") or "").strip().lower()

    if preferred == "pytesseract":
        order = [("pytesseract", _try_tesseract), ("rapidocr", _try_rapidocr)]
    else:
        order = [("rapidocr", _try_rapidocr), ("pytesseract", _try_tesseract)]

    _ENGINE = ""
    for name, probe in order:
        if probe():
            _ENGINE = name
            break

    if _ENGINE:
        logger.info("[OCR] Using engine: %s", _ENGINE)
    else:
        logger.warning(
            "[OCR] No OCR engine available — install "
            "'rapidocr-onnxruntime' (pip only) or the tesseract-ocr system "
            "package with pytesseract."
        )
    return _ENGINE


def image_to_text(
    image_bytes: bytes, lang: str = "eng", min_chars: int = 12
) -> Tuple[str, str]:
    """OCR an image.

    Returns (text, engine_name). Raises OCRUnavailable when no engine is
    installed, and ValueError when the image yields too little text to be
    worth sending to the LLM (avoids paying for a call over three
    characters of noise).
    """
    engine = available_engine()
    if not engine:
        raise OCRUnavailable(
            "No OCR engine available. Install the 'tesseract-ocr' system "
            "package plus pytesseract, or 'rapidocr-onnxruntime' if system "
            "packages cannot be installed."
        )

    img = _preprocess(image_bytes)

    if engine == "pytesseract":
        import pytesseract
        # psm 6 = assume a uniform block of text, which suits screenshots of
        # emails and forms better than the default page segmentation.
        text = pytesseract.image_to_string(img, lang=lang, config="--psm 6")
    else:
        global _RAPID
        import numpy as np
        from PIL import Image as _PILImage
        from rapidocr_onnxruntime import RapidOCR
        if _RAPID is None:
            # First call loads the ONNX models (a few seconds); cached after.
            _RAPID = RapidOCR()
        # RapidOCR expects a 3-channel array; _preprocess returns greyscale.
        rgb = img.convert("RGB") if img.mode != "RGB" else img
        result, _ = _RAPID(np.array(rgb))
        # result rows are [box, text, confidence]
        text = "\n".join(
            str(line[1]) for line in (result or []) if len(line) > 1
        )

    text = (text or "").strip()
    if len(text) < min_chars:
        raise ValueError(
            f"OCR produced only {len(text)} character(s) — "
            "image likely has no readable text"
        )
    return text, engine
