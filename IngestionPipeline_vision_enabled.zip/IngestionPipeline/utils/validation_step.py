"""
utils/validation_step.py — post-parse validation stage.

Runs the quote-to-order validation agent ONCE PER OPPORTUNITY after its
documents have been parsed, and writes a compact verdict to the
opportunity's folder:

    processed_files/OPP-0007724692/validation.json

    {
      "validation": {
        "status":    "Y",              # Y = ready for order, N = not
        "reasoning": "...",            # why, in one short block
        "comments":  "",               # filled by the frontend (preserved)
        "date":      "2026-08-12T09:31:04Z"
      },
      "report": { ...full agent JSON... }   # per-check detail for the UI
    }

DESIGN NOTES
- Per opportunity, not per file: the checks compare documents against each
  other (tech spec vs vendor quote vs PO), so they only make sense once the
  whole opportunity is parsed.
- NEVER blocks the pipeline. Any failure produces status "N" with the error
  in `reasoning`; parsing results are already saved by this point.
- `comments` is NEVER overwritten. It is written by humans in the frontend;
  a re-run merges the previous value forward. Same for any human feedback
  the agent itself recorded.
- google-adk is imported lazily so the pipeline still runs (with validation
  disabled) in environments where the agent's dependencies aren't installed.
"""

import asyncio
import json
import threading
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

VALIDATION_FILENAME = "validation.json"

# All dates written into validation.json use DD-MM-YYYY (with a 24h time
# where a precise moment matters). NOTE: this is a display format, not a
# sortable one — the pipeline's internal ledger deliberately keeps ISO-8601
# because change detection compares those strings.
DATE_FORMAT = "%d-%m-%Y"
TIMESTAMP_FORMAT = "%d-%m-%Y %H:%M:%S"


# opp_id -> token counters for this process. Populated from the ADK event
# stream, which carries usage_metadata on model responses.
METRICS: Dict[str, Dict[str, int]] = {}


def _metrics_start(opp_id: str) -> None:
    METRICS[opp_id] = {
        "input_tokens": 0, "output_tokens": 0, "total_tokens": 0,
        "model_calls": 0,
    }


def _metrics_add_tokens(
    opp_id: str, prompt: int, candidates: int, total: int
) -> None:
    m = METRICS.get(opp_id)
    if not m:
        return
    m["input_tokens"] += int(prompt or 0)
    m["output_tokens"] += int(candidates or 0)
    m["total_tokens"] += int(total or (prompt or 0) + (candidates or 0))
    m["model_calls"] += 1


def get_metrics(opp_id: str) -> Dict[str, int]:
    """Token usage accumulated for one opportunity (zeros if unknown)."""
    return dict(METRICS.get(opp_id) or {
        "input_tokens": 0, "output_tokens": 0,
        "total_tokens": 0, "model_calls": 0,
    })


def _now() -> str:
    """Current UTC timestamp in DD-MM-YYYY HH:MM:SS."""
    return datetime.now(timezone.utc).strftime(TIMESTAMP_FORMAT)


class ValidationAgentUnavailable(RuntimeError):
    """The validation agent could not be loaded at all.

    Systemic, not per-document: every opportunity would fail identically,
    so the run stops rather than writing hundreds of misleading "N"
    verdicts. Parsing results are already persisted when this is raised.
    """


# Backwards-compatible alias.
ValidationUnavailable = ValidationAgentUnavailable


class ValidationRunner:
    """Invokes the validation agent and persists its verdict."""

    def __init__(self, cfg, gcs):
        self.cfg = cfg
        self.gcs = gcs
        self._agent = None
        self._runner = None
        self._session_service = None
        # ONE event loop for every agent call. asyncio.run() creates a fresh
        # loop each time, but the ADK runner's HTTP client binds to the loop
        # it was created on — the second call then dies with "attached to a
        # different loop". Worse with parallel workers. A single long-lived
        # loop in a background thread avoids both.
        self._loop = None
        self._loop_thread = None
        self._loop_lock = threading.Lock()

    # ------------------------------------------------------------ agent

    def _ensure_agent(self) -> bool:
        """Lazily build the ADK runner. Returns False if unavailable."""
        if self._runner is not None:
            return True
        try:
            # The agent reads GCS_BASE_PATH at IMPORT time to decide where
            # the parsed opportunity folders live. Derive it from the
            # pipeline's own config so the two can't drift apart — a
            # mismatch here makes every check fail with "not_found" rather
            # than anything obviously wrong.
            import os

            gcs_cfg = self.cfg.gcs
            base = (
                f"gs://{gcs_cfg.destination_bucket}/"
                f"{gcs_cfg.input_prefix}{gcs_cfg.parsed_prefix}"
            ).rstrip("/")
            os.environ.setdefault("GCS_BASE_PATH", base)
            logger.info("[Validation] Agent GCS_BASE_PATH=%s",
                        os.environ["GCS_BASE_PATH"])

            from google.adk.runners import Runner
            from google.adk.sessions import InMemorySessionService
            from validation_agent import validation_agent

            self._session_service = InMemorySessionService()
            self._runner = Runner(
                agent=validation_agent,
                app_name="qto_validation",
                session_service=self._session_service,
            )
            return True
        except Exception as exc:
            logger.error(
                "Validation agent unavailable (%s) — skipping validation. "
                "Install google-adk + google-cloud-bigquery, or set "
                "validation.enabled=false.", exc,
            )
            return False

    def preflight(self) -> None:
        """Verify the agent loads before validating anything.

        Raises ValidationAgentUnavailable if it doesn't, so the caller can
        stop the run instead of producing a bogus verdict per opportunity.
        """
        if not self._ensure_agent():
            raise ValidationAgentUnavailable(
                "The validation agent could not be loaded. Check that "
                "google-adk and google-cloud-bigquery are installed, that "
                "validation_agent.py imports cleanly (it calls "
                "aiplatform.init() and fetches ID token credentials at "
                "import time), and that the service account can reach the "
                "LLM proxy. Set validation.fail_fast=false to continue the "
                "run and record the failure per opportunity instead."
            )

    def _ensure_loop(self):
        """Start (once) a background thread running a persistent event loop."""
        with self._loop_lock:
            if self._loop is not None and not self._loop.is_closed():
                return self._loop
            loop = asyncio.new_event_loop()

            def _run():
                asyncio.set_event_loop(loop)
                loop.run_forever()

            t = threading.Thread(
                target=_run, name="validation-agent-loop", daemon=True
            )
            t.start()
            self._loop, self._loop_thread = loop, t
            return loop

    def _ask_agent_sync(self, opp_id: str, timeout: float = 600.0) -> str:
        """Run one agent turn on the shared loop and return its final text."""
        loop = self._ensure_loop()
        fut = asyncio.run_coroutine_threadsafe(self._ask_agent(opp_id), loop)
        try:
            return fut.result(timeout=timeout)
        except Exception:
            fut.cancel()
            raise

    def shutdown(self) -> None:
        """Stop the background loop (best effort)."""
        loop = self._loop
        if loop is not None and not loop.is_closed():
            loop.call_soon_threadsafe(loop.stop)
        self._loop = None

    async def _ask_agent(self, opp_id: str) -> str:
        """Run one agent turn and return its final text response."""
        from google.genai import types as gtypes

        session = await self._session_service.create_session(
            app_name="qto_validation", user_id="pipeline"
        )
        # The model cannot know today's date reliably, and VAL-008 needs it
        # to distinguish "was valid when quoted" from "still valid now".
        today = datetime.now(timezone.utc).strftime(DATE_FORMAT)
        message = gtypes.Content(
            role="user",
            parts=[gtypes.Part(
                text=f"Validate opportunity {opp_id}. "
                     f"PROCESSING DATE (today) is {today}. "
                     f"Return only the JSON report."
            )],
        )
        final = ""
        async for event in self._runner.run_async(
            user_id="pipeline",
            session_id=session.id,
            new_message=message,
        ):
            # Cost metrics: every model response carries usage_metadata.
            # An agent turn makes several calls (tool-calling loop), so
            # these accumulate. Metrics must never break a run.
            try:
                um = getattr(event, "usage_metadata", None)
                if um is not None:
                    _metrics_add_tokens(
                        opp_id,
                        getattr(um, "prompt_token_count", 0) or 0,
                        getattr(um, "candidates_token_count", 0) or 0,
                        getattr(um, "total_token_count", 0) or 0,
                    )
            except Exception:  # noqa: BLE001
                pass

            if event.is_final_response() and event.content and event.content.parts:
                for part in event.content.parts:
                    if getattr(part, "text", None):
                        final += part.text
        return final

    # ------------------------------------------------------------- run

    @staticmethod
    def _extract_checks(report: Dict[str, Any]) -> Dict[str, Dict[str, str]]:
        """Flatten every check in a report to {id: {status, reason, action}}."""
        out: Dict[str, Dict[str, str]] = {}
        for section in (
            "val_checks", "required_information", "checks",
            "bsp_base_checks", "circuit_checks",
        ):
            for item in report.get(section) or []:
                if not isinstance(item, list) or len(item) < 3:
                    continue
                out[str(item[0])] = {
                    "status": str(item[1]).strip().upper(),
                    "reason": str(item[2]),
                    "action": str(item[3]) if len(item) > 3 else "none",
                }
        return out

    def _build_resolution(
        self, report: Dict[str, Any], existing: Dict[str, Any], now: str
    ) -> Dict[str, Any]:
        """Compare this run's verdicts with the previous run's.

        A check that failed before and passes now is RESOLVED — typically
        because the missing document was added under Modified-File. Showing
        that transition matters: "N then Y" is evidence the gap was closed,
        whereas a bare "Y" looks like it was never a problem. Where the
        original failure raised a request (raise_sales / raise_mdg), the
        request is tagged resolved so it can be closed.
        """
        prev_hist: Dict[str, Any] = (existing.get("check_history") or {})
        current = self._extract_checks(report)

        history: Dict[str, Any] = {}
        resolved, still_failing, new_failures, regressed = [], [], [], []

        for cid, cur in current.items():
            old = prev_hist.get(cid) or {}
            old_status = old.get("status")
            entry: Dict[str, Any] = {
                "status": cur["status"],
                "reason": cur["reason"],
                "action": cur["action"],
                "last_checked": now,
            }
            # carry history forward
            for k in ("first_failed_at", "request_raised", "request_action"):
                if k in old:
                    entry[k] = old[k]

            if cur["status"] == "N":
                entry.setdefault("first_failed_at", old.get("first_failed_at") or now)
                if cur["action"] and cur["action"].lower() not in ("none", ""):
                    entry["request_raised"] = True
                    entry["request_action"] = cur["action"]
                    entry["request_status"] = "open"
                if old_status == "N":
                    still_failing.append(cid)
                elif old_status == "Y":
                    regressed.append(cid)
                    entry["regressed_at"] = now
                else:
                    new_failures.append(cid)

            elif cur["status"] == "Y" and old_status == "N":
                entry["resolved"] = True
                entry["resolved_at"] = now
                entry["previous_status"] = "N"
                entry["previously_failed_because"] = old.get("reason", "")
                if old.get("request_raised"):
                    # The request raised for the original failure can close.
                    entry["request_raised"] = True
                    entry["request_action"] = old.get("request_action", "")
                    entry["request_status"] = "resolved"
                resolved.append({
                    "check": cid,
                    "was": "N",
                    "now": "Y",
                    "first_failed_at": old.get("first_failed_at"),
                    "resolved_at": now,
                    "previously": old.get("reason", ""),
                    "now_because": cur["reason"],
                    "request_action": old.get("request_action"),
                    "request_status": (
                        "resolved" if old.get("request_raised") else None
                    ),
                })
            history[cid] = entry

        return {
            "history": history,
            "summary": {
                "resolved": resolved,
                "still_failing": still_failing,
                "new_failures": new_failures,
                "regressed": regressed,
                "previous_overall": existing.get("validation", {}).get("status"),
            },
        }

    def validate(self, opp_id: str, bucket: str, opp_dir: str) -> Optional[Dict[str, Any]]:
        """Validate one opportunity and write validation.json.

        Returns the written payload, or None if validation was skipped.
        Never raises — a validation failure must not fail the parse run.
        """
        existing = self._load_existing(bucket, opp_dir)
        _metrics_start(opp_id)

        report: Dict[str, Any] = {}
        status = "N"
        reasoning = ""

        if not self._ensure_agent():
            # Reached only when fail_fast is off — preflight() already
            # aborted the run otherwise. Record it so the frontend can tell
            # a broken environment from a genuine validation failure.
            reasoning = (
                "Validation could not run: the validation agent is not "
                "available in this environment. This is a system error, "
                "not a document problem."
            )
            report = {"error": "agent_unavailable"}
        else:
            try:
                raw = self._ask_agent_sync(opp_id)
                report = self._parse_report(raw)
                status, reasoning = self._summarize(report)
            except Exception as exc:
                logger.exception("[Validation] %s failed: %s", opp_id, exc)
                reasoning = (
                    f"Validation could not be completed: {exc}. "
                    "Parsed documents are unaffected."
                )
                report = {"error": str(exc)}

        now = _now()
        resolution = self._build_resolution(report, existing, now)
        res = resolution["summary"]

        # Surface resolutions in the human-readable reasoning too.
        if res["resolved"]:
            bits = []
            for r in res["resolved"]:
                tag = " [request resolved]" if r.get("request_status") == "resolved" else ""
                bits.append(f"{r['check']}{tag}")
            reasoning = (
                f"RESOLVED since last run: {', '.join(bits)}. " + reasoning
            )
        if res["regressed"]:
            reasoning = (
                f"REGRESSED (was passing): {', '.join(res['regressed'])}. "
                + reasoning
            )

        payload = {
            "validation": {
                "status": status,
                "reasoning": reasoning,
                # Human feedback from the frontend — carried forward, never
                # overwritten by a re-run.
                "comments": (existing.get("validation") or {}).get("comments", ""),
                "date": now,
                "previous_status": existing.get("validation", {}).get("status"),
                "resolved_checks": [r["check"] for r in res["resolved"]],
                "open_requests": [
                    cid for cid, e in resolution["history"].items()
                    if e.get("request_status") == "open"
                ],
            },
            "opportunity_id": opp_id,
            "token_usage": get_metrics(opp_id),
            "resolution": res,
            "check_history": resolution["history"],
            "report": report,
        }

        out_path = opp_dir + VALIDATION_FILENAME
        try:
            self.gcs.upload_json(bucket, out_path, payload)
            logger.info(
                "[Validation] %s -> status=%s | written to gs://%s/%s",
                opp_id, status, bucket, out_path,
            )
        except Exception:
            logger.exception(
                "[Validation] FAILED to write gs://%s/%s — validation ran "
                "but the result could not be saved", bucket, out_path,
            )
        return payload

    # --------------------------------------------------------- helpers

    def _load_existing(self, bucket: str, opp_dir: str) -> Dict[str, Any]:
        try:
            raw = self.gcs.download_bytes(
                bucket, opp_dir + VALIDATION_FILENAME
            )
            data = json.loads(raw)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    @staticmethod
    def _parse_report(raw: str) -> Dict[str, Any]:
        """Extract the JSON report from the agent's reply."""
        text = (raw or "").strip()
        if text.startswith("```"):
            # strip ```json ... ``` fences if the model added them
            text = text.split("```")[1] if "```" in text[3:] else text[3:]
            if text.lstrip().lower().startswith("json"):
                text = text.lstrip()[4:]
        text = text.strip().strip("`").strip()
        start, end = text.find("{"), text.rfind("}")
        if start == -1 or end == -1:
            raise ValueError("agent returned no JSON object")
        return json.loads(text[start: end + 1])

    @staticmethod
    def _summarize(report: Dict[str, Any]) -> tuple:
        """Reduce the full agent report to (status, reasoning)."""
        overall = report.get("overall") or {}
        status = str(overall.get("ready_for_order", "N")).strip().upper()
        status = "Y" if status == "Y" else "N"

        blocking = overall.get("blocking_issues") or []
        review = overall.get("needs_human_review") or []

        # Which individual checks failed, for a concrete reason string.
        # "NA" (rule not applicable to this order type) is NOT a failure.
        failed = []
        for section in (
            "val_checks",                      # VAL-Q2O catalogue
            "required_information", "checks",
            "bsp_base_checks", "circuit_checks",
        ):
            for item in report.get(section) or []:
                if (
                    isinstance(item, list) and len(item) >= 3
                    and str(item[1]).strip().upper() == "N"
                ):
                    failed.append(f"{item[0]}: {item[2]}")

        if status == "Y" and not failed:
            # A pass can still carry advisories — e.g. VAL-008 judging a
            # vendor quote valid at the customer quote date while noting it
            # is stale today. Collapsing to "all passed" would hide exactly
            # the thing a reviewer needs to see.
            notes = []
            for section in (
                "val_checks", "required_information", "checks",
                "bsp_base_checks", "circuit_checks",
            ):
                for item in report.get(section) or []:
                    if (
                        isinstance(item, list) and len(item) >= 3
                        and "NOTE:" in str(item[2])
                    ):
                        note = str(item[2]).split("NOTE:", 1)[1].strip()
                        notes.append(f"{item[0]}: {note}")
            parts = ["All validation checks passed."]
            if notes:
                parts.append("Notes — " + " | ".join(notes))
            if review:
                parts.append("Needs review: " + "; ".join(map(str, review)))
            return "Y", " ".join(parts)

        parts = []
        if blocking:
            parts.append("Blocking: " + "; ".join(map(str, blocking)))
        if failed:
            shown = failed[:10]
            parts.append("Failed checks — " + " | ".join(shown))
            if len(failed) > len(shown):
                parts.append(f"(+{len(failed) - len(shown)} more)")
        if review:
            parts.append("Needs review: " + "; ".join(map(str, review)))
        return status, " ".join(parts) or "Validation did not pass."
