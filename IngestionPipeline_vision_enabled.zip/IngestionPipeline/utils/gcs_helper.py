"""gcs_helper.py — thin wrapper around google-cloud-storage"""

import json
import logging
import time
import posixpath
from datetime import datetime, timezone
from typing import Dict, List, Optional

from google.cloud import storage
from google.api_core.exceptions import (
    NotFound,
    PreconditionFailed,
    TooManyRequests,
)

logger = logging.getLogger(__name__)


class GCSHelper:
    def __init__(self, project_id: str):
        self.client = storage.Client(project=project_id)
        # Last write time per object, used to respect the GCS limit of
        # ~1 mutation per second per object.
        self._last_state_save: Dict[str, float] = {}

    # ------------------------------------------------------------ run lock

    def acquire_run_lock(
        self, bucket_name: str, blob_name: str, lease_seconds: int = 900
    ) -> bool:
        """Atomically acquire a run lock.

        Creating the blob with if_generation_match=0 succeeds only if it
        doesn't already exist — GCS guarantees atomicity, so two concurrent
        runs (scheduler + manual trigger) can never both proceed. A crashed
        run's lock is stolen after lease_seconds.
        """
        bucket = self.client.bucket(bucket_name)
        payload = json.dumps(
            {"acquired_at": datetime.now(timezone.utc).isoformat()}
        ).encode()

        for _ in range(2):  # one retry after stealing / vanishing lock
            blob = bucket.blob(blob_name)
            try:
                blob.upload_from_string(
                    payload,
                    content_type="application/json",
                    if_generation_match=0,
                )
                logger.info("Acquired run lock gs://%s/%s", bucket_name, blob_name)
                return True
            except PreconditionFailed:
                existing = bucket.get_blob(blob_name)
                if existing is None:
                    continue  # released between our calls — try again
                age = (
                    datetime.now(timezone.utc) - existing.updated
                ).total_seconds()
                if age <= lease_seconds:
                    logger.warning(
                        "Run lock gs://%s/%s held for %.0fs — another run "
                        "is in progress",
                        bucket_name, blob_name, age,
                    )
                    return False
                logger.warning(
                    "Stealing stale run lock (age %.0fs > lease %ds) — "
                    "previous run likely crashed",
                    age, lease_seconds,
                )
                try:
                    existing.delete(if_generation_match=existing.generation)
                except (PreconditionFailed, NotFound):
                    return False  # someone else stole it first
        return False

    def renew_run_lock(
        self, bucket_name: str, blob_name: str, min_interval: float = 60.0
    ) -> None:
        """Refresh the lock's timestamp. Called periodically during a run so
        a long backfill (hours) can't be mistaken for a crashed run and have
        its lock stolen by a scheduled invocation.

        Throttled: the lock is a single object and GCS caps mutations at
        ~1/second per object. Renewing once a minute is ample against a
        900s lease.
        """
        key = f"lock:{bucket_name}/{blob_name}"
        now = time.monotonic()
        if now - self._last_state_save.get(key, 0.0) < min_interval:
            return
        try:
            payload = json.dumps(
                {"renewed_at": datetime.now(timezone.utc).isoformat()}
            ).encode()
            self.client.bucket(bucket_name).blob(blob_name).upload_from_string(
                payload, content_type="application/json"
            )
            self._last_state_save[key] = time.monotonic()
        except TooManyRequests:
            logger.debug("Lock renewal rate-limited — lease still valid")
        except Exception:
            logger.exception(
                "Failed to renew run lock gs://%s/%s", bucket_name, blob_name
            )

    def release_run_lock(self, bucket_name: str, blob_name: str) -> None:
        try:
            self.client.bucket(bucket_name).blob(blob_name).delete()
            logger.info("Released run lock gs://%s/%s", bucket_name, blob_name)
        except NotFound:
            pass
        except Exception:
            logger.exception(
                "Failed to release run lock gs://%s/%s — it will expire "
                "after the lease period",
                bucket_name, blob_name,
            )



    def list_blobs(self, bucket_name: str, prefix: str) -> List[storage.Blob]:
        """Return all blobs under *prefix* (non-recursive would need delimiter)."""
        bucket = self.client.bucket(bucket_name)
        return list(bucket.list_blobs(prefix=prefix))


    def copy_blobs(
        self,
        source_bucket_name: str,
        source_prefix: str,
        destination_bucket_name: str,
        destination_prefix: str = "",
        name_filter: Optional[str] = None,
    ) -> None:
        """Copy only new or updated objects.

        name_filter: if given, only objects whose path contains this string
        (case-insensitive) are copied. Used to sync a single opportunity
        without walking the whole bucket — an OPP's folders are spread
        across the base prefix AND Modified-File/, so it can't be expressed
        as a single prefix.
        """

        source_prefix = source_prefix or ""
        destination_prefix = destination_prefix or ""

        blobs = self.list_blobs(source_bucket_name, source_prefix)
        if name_filter:
            needle = name_filter.lower()
            before = len(blobs)
            blobs = [b for b in blobs if needle in b.name.lower()]
            logger.info(
                "Sync filtered to '%s': %d of %d object(s)",
                name_filter, len(blobs), before,
            )

        source_bucket = self.client.bucket(source_bucket_name)
        destination_bucket = self.client.bucket(destination_bucket_name)

        for blob in blobs:

            if blob.name.endswith("/"):
                continue

            rel_name = (
                blob.name[len(source_prefix):]
                if source_prefix and blob.name.startswith(source_prefix)
                else blob.name
            )

            dest_blob_name = posixpath.join(
                destination_prefix,
                rel_name,
            )

            dest_blob = destination_bucket.get_blob(dest_blob_name)

            # File does not exist yet
            if dest_blob is None:
                source_bucket.copy_blob(
                    blob,
                    destination_bucket,
                    dest_blob_name,
                )

                logger.info(
                    "Copied new file gs://%s/%s -> gs://%s/%s",
                    source_bucket_name,
                    blob.name,
                    destination_bucket_name,
                    dest_blob_name,
                )
                continue

            # Only copy if source is newer
            if blob.updated > dest_blob.updated:

                source_bucket.copy_blob(
                    blob,
                    destination_bucket,
                    dest_blob_name,
                )

                logger.info(
                    "Updated file gs://%s/%s -> gs://%s/%s",
                    source_bucket_name,
                    blob.name,
                    destination_bucket_name,
                    dest_blob_name,
                )

    def copy_blob_within(
        self, bucket_name: str, src_blob: str, dst_blob: str
    ) -> bool:
        """Server-side copy inside one bucket. Used to reuse a parsed result
        for a byte-identical input instead of calling the LLM again."""
        bucket = self.client.bucket(bucket_name)
        src = bucket.get_blob(src_blob)
        if src is None:
            return False
        bucket.copy_blob(src, bucket, dst_blob)
        return True

    def move_blob(
        self, bucket_name: str, src_blob: str, dst_blob: str
    ) -> bool:
        """Move an object within a bucket (server-side copy, then delete).

        Returns False if the source doesn't exist. Used to demote a parsed
        output into archive/ when a newer source version supersedes it —
        no re-parsing, so no LLM cost.
        """
        bucket = self.client.bucket(bucket_name)
        src = bucket.get_blob(src_blob)
        if src is None:
            return False
        bucket.copy_blob(src, bucket, dst_blob)
        src.delete()
        logger.info(
            "Moved gs://%s/%s -> %s", bucket_name, src_blob, dst_blob
        )
        return True

    def download_bytes(self, bucket_name: str, blob_name: str) -> bytes:
        bucket = self.client.bucket(bucket_name)
        blob = bucket.blob(blob_name)
        return blob.download_as_bytes()


    def upload_bytes(
        self,
        bucket_name: str,
        blob_name: str,
        data: bytes,
        content_type: str = "application/octet-stream",
    ) -> None:
        bucket = self.client.bucket(bucket_name)
        blob = bucket.blob(blob_name)
        blob.upload_from_string(data, content_type=content_type)
        logger.info("Uploaded %s bytes > gs://%s/%s", len(data), bucket_name, blob_name)

    def upload_json(
        self, bucket_name: str, blob_name: str, payload: dict
    ) -> None:
        self.upload_bytes(
            bucket_name,
            blob_name,
            json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"),
            content_type="application/json",
        )



    def load_state(self, bucket_name: str, blob_name: str) -> dict:
        """Load the processed-files ledger.

        Only a missing blob means "fresh start". Any other failure
        (permissions, network, corrupt JSON) raises — silently returning {}
        would cause a full, expensive reprocess of every file.
        """
        try:
            raw = self.download_bytes(bucket_name, blob_name)
        except NotFound:
            logger.info(
                "State blob gs://%s/%s not found — first run, starting fresh",
                bucket_name, blob_name,
            )
            return {}

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            logger.exception(
                "State blob gs://%s/%s exists but is not valid JSON — "
                "refusing to silently reprocess everything. Fix or delete it.",
                bucket_name, blob_name,
            )
            raise



    def save_state(
        self,
        bucket_name: str,
        blob_name: str,
        state: dict,
        min_interval: float = 0.0,
        force: bool = False,
    ) -> bool:
        """Persist the ledger.

        GCS allows roughly ONE mutation per second per object. The pipeline
        saves after every batch, and fast batches can finish well inside
        that window — which returned 429 rateLimitExceeded and killed the
        run. So:
          - `min_interval` skips a save if the last one was too recent
            (the next batch will persist the same data moments later);
          - `force=True` bypasses the throttle for the final save, where
            losing progress actually matters;
          - 429s are retried with backoff instead of propagating.
        Returns True if the state was written.
        """
        now = time.monotonic()
        key = f"{bucket_name}/{blob_name}"
        if not force and min_interval > 0:
            last = self._last_state_save.get(key, 0.0)
            if now - last < min_interval:
                logger.debug(
                    "Skipping state save (%.1fs since last, min %.1fs)",
                    now - last, min_interval,
                )
                return False

        payload = json.dumps(state, indent=2).encode("utf-8")
        blob = self.client.bucket(bucket_name).blob(blob_name)

        delay = 1.0
        for attempt in range(5):
            try:
                blob.upload_from_string(
                    payload, content_type="application/json"
                )
                self._last_state_save[key] = time.monotonic()
                logger.info(
                    "Uploaded %d bytes > gs://%s/%s",
                    len(payload), bucket_name, blob_name,
                )
                return True
            except TooManyRequests:
                if attempt == 4:
                    raise
                logger.warning(
                    "State save rate-limited (429) — retrying in %.1fs "
                    "(attempt %d/5)", delay, attempt + 1,
                )
                time.sleep(delay)
                delay *= 2
        return False
