# GCS Data Ingestion Pipeline

## Quickstart 

### Step 1 — Fill in `config.yaml`

Open `config.yaml` and fill in the values marked with `←`. If you want to sync files from a separate source bucket first, set `gcs.source_bucket`, `gcs.source_project_id`, and optionally `gcs.source_prefix`.

For your VBOP data, the source prefix should match the folder root inside the bucket, and the pipeline will preserve the opportunity subfolders:

```yaml
gcp:
  project_id: "vf-ie-dhk"    
  location:   "europe-west1"      

gcs:
  source_bucket: "vfgrp-dh-advanced-analytics"
  source_project_id: "vf-grp-dhk"
  source_prefix: "VFIE-Complex-Fixed-Products-VBOP-Extracts/"
  destination_bucket: "vfie-dh-customer-complex-fixed"
  destination_project_id: "vf-ie-dhk"
  input_bucket: "vfie-dh-customer-complex-fixed"
  input_prefix: "VFIE-Complex-Fixed-Products-VBOP-Extracts/"
  parsed_prefix: "parsed_files/"
```

This will copy `gs://vfgrp-dh-advanced-analytics/VFIE-Complex-Fixed-Products-VBOP-Extracts/...` into `gs://vfie-dh-customer-complex-fixed/VFIE-Complex-Fixed-Products-VBOP-Extracts/...`, retaining opportunity-ID folders like `6523_OPP-0007063044_02012025_1046/`.

---

### Step 2 — Enable GCP APIs 

```bash
gcloud services enable \
  cloudfunctions.googleapis.com \
  cloudscheduler.googleapis.com \
  bigquery.googleapis.com \
  aiplatform.googleapis.com \
  storage.googleapis.com \
  --project=YOUR_PROJECT_ID
```

---

### Step 3 — Deploy

```bash
chmod +x deploy.sh
./deploy.sh
```

That's it. The pipeline will run every 15 minutes automatically.

---


**Input  Output examples:**

| Input file | Output |
|------------|--------|
| `files/invoices/inv001.pdf` | `parsed_files/invoices/inv001.json` |
| `files/contracts/agreement.docx` | `parsed_files/contracts/agreement.json` |
| `files/data/sales.xlsx` (clean table) | rows inserted into BigQuery |
| `files/forms/customer_info.xlsx` (label/value form) | `parsed_files/forms/customer_info_extracted.json` |
| `files/inbox/email.msg` | `parsed_files/inbox/email.json` |
| `files/inbox/email.msg` with `invoice.pdf` attached | also > `parsed_files/inbox/attachments/invoice.json` |

---

## Supported file types

| Extension | How it's processed | Output |
|-----------|-------------------|--------|
| `.pdf` | Text PDFs > Gemini reads text. Scanned/image PDFs > Gemini Vision | JSON > GCS |
| `.docx` `.doc` | Text extracted, sent to Gemini | JSON > GCS |
| `.xlsx` `.xls` | Every non-empty cell dumped with its sheet/row/col position, then Gemini decides per-sheet whether it's a form (label/value pairs) or a table (header + rows) see below | Tables > BigQuery, forms > JSON > GCS |
| `.csv` | Always a single table read directly with pandas, no Gemini step needed | Rows > BigQuery |
| `.msg` | Email body + metadata extracted, attachments routed automatically | JSON > GCS |


## Running locally (for testing)

```bash

python -m venv .venv

.venv/Scripts/activate

pip install -r requirements.txt

export GCP_PROJECT_ID="your-project-id"

python main.py
```


## Project structure

```
config.yaml          ← THE FILE TO EDIT
main.py              ← Cloud Run Functions entry point
pipeline.py          ← Router: reads GCS, routes files, saves output
deploy.sh            ← Deploys function + scheduler
requirements.txt     ← Python dependencies

parsers/
  pdf_parser.py      ← Handles text and scanned PDFs
  docx_parser.py     ← Extracts text from Word documents
  excel_parser.py    ← Dumps cells, Gemini classifies form vs table, routes to JSON
  email_parser.py    ← Parses .msg files, routes attachments

utils/
  config_loader.py   ← Reads config.yaml
  gcs_helper.py      ← GCS read/write + processed-file tracker
  gemini_client.py   ← Gemini API calls with retry

```

## This pipeline is created by Shereen Elmasry for more inquiries please contant on (shelmasry@deloitte.com)
