"""
parsers/docx_parser.py

Extracts text (paragraphs + tables) from .docx files via python-docx,
then sends to Gemini for structured JSON extraction.
"""

import io
import json
import logging
from typing import Dict, Any

from docx import Document
from docx.oxml.ns import qn

from utils.gemini_client import GeminiClient, GENERIC_JSON_PROMPT

logger = logging.getLogger(__name__)


class DOCXParser:
    def __init__(self, gemini: GeminiClient):
        self.gemini = gemini

    def parse(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        # .docx is a zip (magic "PK"). Many ".doc" files in the wild are
        # really docx with the wrong extension — those parse fine. A true
        # Word 97-2003 binary .doc has no reliable pure-Python parser, so
        # produce a traceable error output instead of crash-retrying it.
        if not file_bytes.startswith(b"PK"):
            logger.warning(
                "[DOCX] %s is a legacy binary .doc — cannot parse without "
                "conversion; writing an error record", filename,
            )
            return {
                "_meta": {"source_file": filename},
                "error": "Legacy binary .doc format — convert to .docx upstream to parse",
            }

        doc = Document(io.BytesIO(file_bytes))

        text_content = self._extract_text(doc)
        table_content = self._extract_tables(doc)

        combined = text_content
        if table_content:
            combined += "\n\n--- TABLES ---\n\n" + table_content

        logger.info(
            "[DOCX] %s — extracted %d chars", filename, len(combined)
        )

        raw = self.gemini.extract_from_text(combined, GENERIC_JSON_PROMPT)
        result = self._safe_parse_json(raw, filename)
        result["_meta"] = {
            "source_file": filename,
            "char_count": len(combined),
        }
        return result

    @staticmethod
    def _extract_text(doc: Document) -> str:
        paragraphs = []
        for para in doc.paragraphs:
            text = para.text.strip()
            if text:
                paragraphs.append(text)
        return "\n".join(paragraphs)

    @staticmethod
    def _extract_tables(doc: Document) -> str:
        tables_text = []
        for t_idx, table in enumerate(doc.tables):
            rows = []
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells]
                rows.append(" | ".join(cells))
            tables_text.append(f"Table {t_idx + 1}:\n" + "\n".join(rows))
        return "\n\n".join(tables_text)

    @staticmethod
    def _safe_parse_json(raw: str, label: str) -> Dict[str, Any]:
        try:
            clean = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
            return json.loads(clean)
        except json.JSONDecodeError:
            logger.warning("[DOCX] Could not parse JSON for %s", label)
            return {"raw_extraction": raw, "parse_error": True}
