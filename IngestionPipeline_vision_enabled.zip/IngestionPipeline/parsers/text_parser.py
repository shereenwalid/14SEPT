import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)


class TextParser:

    def parse(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:

        text = file_bytes.decode("utf-8", errors="ignore")

        result = {}

        for line in text.splitlines():
            line = line.strip()

            if not line:
                continue

            if ":" not in line:
                continue

            key, value = line.split(":", 1)

            result[key.strip()] = value.strip()

        result["_meta"] = {
            "source_file": filename,
        }

        return result
