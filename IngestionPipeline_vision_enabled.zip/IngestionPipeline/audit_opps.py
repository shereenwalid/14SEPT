"""
audit_opps.py — opportunity-level progress report.

Answers: how many OPP folders exist, how many are parsed, how many are
validated, and how many are left.

Counts OPPORTUNITIES, not files (audit_missing.py does files). Run it any
time during a backfill to see progress.

Usage:
  python audit_opps.py                 # summary + counts
  python audit_opps.py --list-todo     # also list the OPPs still to do
  python audit_opps.py --csv           # write audit_opps.csv

Read-only. Needs google-cloud-storage + pyyaml.
"""

import argparse
import csv
import re
import sys
from collections import Counter
from urllib.parse import unquote

import yaml

OPP_RE = re.compile(r"(OPP-\d+)", re.IGNORECASE)


def opp_of(path: str):
    """OPP id contained in a path, or None."""
    m = OPP_RE.search(unquote(path))
    return m.group(1).upper() if m else None


def is_product_code(path: str) -> bool:
    for seg in path.split("/")[:-1]:
        norm = re.sub(r"[^a-z0-9]", "", unquote(seg).lower())
        if "product" in norm and "code" in norm:
            return True
    return False


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--list-todo", action="store_true",
                    help="list opportunities with no parsed output yet")
    ap.add_argument("--csv", action="store_true",
                    help="write audit_opps.csv with a row per opportunity")
    ap.add_argument("--config", default="config.yaml")
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.config, encoding="utf-8"))
    bucket_name = cfg["gcs"]["destination_bucket"]
    input_prefix = cfg["gcs"]["input_prefix"]
    parsed_prefix = cfg["gcs"]["parsed_prefix"]

    ext_map = set()
    for exts in cfg["supported_extensions"].values():
        ext_map.update(e.lower() for e in exts)

    from google.cloud import storage
    client = storage.Client(
        project=cfg["gcs"].get("destination_project_id")
        or cfg["gcp"]["project_id"]
    )
    bucket = client.bucket(bucket_name)

    out_prefix = input_prefix + parsed_prefix
    print(f"Listing gs://{bucket_name}/{input_prefix} ...")
    names = [b.name for b in bucket.list_blobs(prefix=input_prefix)]

    inputs = [n for n in names
              if not n.startswith(out_prefix) and not n.endswith("/")]
    outputs = [n for n in names if n.startswith(out_prefix)]
    print(f"  {len(inputs)} input file(s), {len(outputs)} output object(s)")

    # --- opportunities on the INPUT side --------------------------------
    src_files = Counter()          # opp -> parseable input files
    for n in inputs:
        if is_product_code(n):
            continue
        ext = ("." + n.rsplit(".", 1)[-1]).lower() if "." in n else ""
        if ext not in ext_map:
            continue
        opp = opp_of(n)
        if opp:
            src_files[opp] += 1

    # --- opportunities on the OUTPUT side --------------------------------
    parsed_files = Counter()       # opp -> parsed outputs (excl. archive)
    archived = Counter()
    validated = {}                 # opp -> True (validation.json present)
    for n in outputs:
        opp = opp_of(n)
        if not opp:
            continue
        base = n.rsplit("/", 1)[-1]
        if base == "validation.json":
            validated[opp] = True
            continue
        if base == "_versions.json":
            continue
        if "/archive/" in n:
            archived[opp] += 1
        else:
            parsed_files[opp] += 1

    all_opps = sorted(set(src_files) | set(parsed_files))
    done, partial, todo = [], [], []
    for opp in all_opps:
        got, want = parsed_files.get(opp, 0), src_files.get(opp, 0)
        if got == 0:
            todo.append(opp)
        elif want and got < want:
            partial.append(opp)
        else:
            done.append(opp)

    # Only count validation for opportunities that actually have parsed
    # output — a validation.json next to no documents is a stale artifact.
    n_val = sum(1 for o in all_opps
                if validated.get(o) and parsed_files.get(o, 0) > 0)
    n_orphan = sum(1 for o in all_opps
                   if validated.get(o) and parsed_files.get(o, 0) == 0)

    print("\n===== OPPORTUNITIES =====")
    print(f"  total found                : {len(all_opps)}")
    print(f"  parsed (has output)        : {len(done) + len(partial)}")
    print(f"    - complete               : {len(done)}")
    print(f"    - partial (some files)   : {len(partial)}")
    print(f"  not parsed yet             : {len(todo)}")
    print(f"  validated (validation.json): {n_val}")
    print(f"  awaiting validation        : "
          f"{max(0, len(done) + len(partial) - n_val)}")
    if n_orphan:
        print(f"  stale validation.json      : {n_orphan} "
              f"(written for OPPs with no parsed output)")

    if args.list_todo and todo:
        print(f"\n----- NOT PARSED YET ({len(todo)}) -----")
        for o in todo[:100]:
            print(f"  {o}  ({src_files.get(o, 0)} input file(s))")
        if len(todo) > 100:
            print(f"  ... and {len(todo) - 100} more")

    if partial:
        print(f"\n----- PARTIAL ({len(partial)}) -----")
        for o in partial[:20]:
            print(f"  {o}: {parsed_files[o]}/{src_files[o]} file(s) parsed")
        if len(partial) > 20:
            print(f"  ... and {len(partial) - 20} more")

    if args.csv:
        with open("audit_opps.csv", "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["opportunity", "input_files", "parsed_files",
                        "archived_files", "validated", "status"])
            for opp in all_opps:
                status = ("not_parsed" if opp in todo
                          else "partial" if opp in partial else "complete")
                w.writerow([opp, src_files.get(opp, 0),
                            parsed_files.get(opp, 0), archived.get(opp, 0),
                            "Y" if validated.get(opp) else "N", status])
        print("\n  Per-opportunity detail: audit_opps.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
